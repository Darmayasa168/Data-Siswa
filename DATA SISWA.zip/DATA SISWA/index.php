<!DOCTYPE html>
<html>
<head>
	<title>DATA SISWA</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">

	<h1 class="text-center">Data Nilai Siswa</h1>
	<h2 class="text-center">SMP Satu Satap Tianyar Tengah</h2>
	<h3 class="text-center">Mata Pelajaran: Matematika</h3>

	<!-- Awal Card Form -->
	<div class="card mt-5">
	  <div class="card-header bg-primary text-white ">
	    Form Input Data Siswa
	  </div>
	  <div class="card-body">
	    <form method="pst" action="">
	    	<div class="form-group">
	    		<label>NISN</label>
	    		<input type="text" name="tnisn" class="form-control" placeholder="Masukan NISN Siswa!" required>
	    	</div>
	    	<div class="form-group">
	    		<label>Nama Siswa</label>
	    		<input type="text" name="tnama siswa" class="form-control" placeholder="Masukan Nama Siswa!" required>
	    	</div>
	    	<div class="form-group">
	    		<label>Kelas</label>
	    		<select class="form-control" name="tkelas">
	    			<option></option>
	    			<option value="7">7</option>
	    			<option value="8">8</option>
	    			<option value="9">9</option>
	    		</select>
	    	</div>
	    	<div class="form-group">
	    		<label>Nilai</label>
	    		<input type="text" name="tnilai" class="form-control" placeholder="Masukan Nilai Siswa!" required>
	    	</div>
	    	

	    	<button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
	    	<button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>

	    </form>
	  </div>
	</div>
	<!-- Akhir Card Form -->

	<!-- Awal Card Tabel -->
	<div class="card mt-5">
	  <div class="card-header bg-success text-white ">
	    Daftar Nilai Siswa
	  </div>
	  <div class="card-body">
	    
	  	<table class="table table-bordered table-striped">
	  		<tr>
	  			<th>No.</th>
	  			<th>Nama</th>
	  			<th>NISN</th>
	  			<th>Kelas</th>
	  			<th>Nilai</th>
	  		</tr>
	  		<?php
	  			$no = 1;
	  			$nilai =45-90;
	  			$tampil = mysqli_query($koneksi, "SELECT * form data siswa order by id_data siswa desc");
	  			while($data = mysqli_fetch_array($tampil)) :

	  		?>
	  		<tr>
	  			<td><?=$no++;?></td>
	  			<td><?=$data['NISN']?></td>
	  			<td><?=$data['Nama']?></td>
	  			<td><?=$data['Kelas']?></td>
	  			<td><?=$nilai++?></td>
	  		</tr>
	  	<?php endwhile; //penutup perulangan while ?>
	  	</table>

	  </div>
	</div>
	<!-- Akhir Card Tabel -->
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>